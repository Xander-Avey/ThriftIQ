# ThriftIQ

AI-powered resale scanner. Upload a photo of any thrifted item and get an instant resale value, flip score, and best platform to sell on.

## Setup

1. Clone this repo
2. Add your `ANTHROPIC_API_KEY` to Vercel environment variables
3. Deploy on Vercel
